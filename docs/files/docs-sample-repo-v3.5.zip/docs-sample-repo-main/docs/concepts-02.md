## Key Concepts: Users, Claims, & Security

## Security and Claim-Based Access Control (CBAC)

VW.AC's connected vehicle services are embedded within multiple layers of security. 

A primary concept used throughout the VW.AC Platform for controlling access and enabling privileges is via the use of **claims** and the implementation of a Claim-Based Access Control (CBAC) mechanism. 

Claims are an effective, flexible, and detail-oriented method to associate specific, time-based rights and privileges to objects, such as a user or a vehicle, or for the pairing of objects, such as a particular user combined with a particular vehicle.

A claim is simply an assertion, or declaration, of an object's status. It is a verified statement of fact about an object.

For example, a claim can be used to establish that user "Peggy" currently has the role of "Renter" for a specific vehicle until a specific end-date and time. Another claim might specify that a particular fleet vehicle should be limited to a specific geographic region, or that a motor pool vehicle can only be reserved by a designated tier of employee or worker.

Claims, by themselves, do not define what an object can or cannot do. They simply define what the object is or is not. Claims must be retrieved and evaluated by the business logic within a developer's application to determine whether an action requested by a user or a service should be approved or denied. 

### Examples of claim requirements

- If a user wants to remotely unlock the doors to their vehicle, there must be a combination of claims that establish that the specific user is authorized to control that distinct feature ("remote door unlock") for the designated vehicle.
- If an entity such as an insurance company wants to retrieve mileage data from a vehicle, there must be a combination of claims that ensure consent has been given by the vehicle's owner for that specific insurance company to collect only the approved data from the designated vehicle until a specific date in the future. 

In practice, claims are often viewed as the means to evaluate the permissibility of a request. For example: "who can do what" to a specified object like a vehicle or a group of vehicles. The "who" in that request is defined by the **user** object. A user can be a specific person (an owner, renter, lessee, a repair technician, etc.) or an entity (the dealer of record, a specific repair shop, the vehicle's manufacturer, etc.).


## The ClaimSet Data Structure

Claims are defined using a **ClaimSet** data structure, which is (generally) a collection of four attributes:

- Name
- Values
- Expiration
- ClaimType

The content allowed for the *values* of a claim's `Name`, `Values`, and `ClaimType` parameters is intentionally unrestricted by the VW.AC Platform. There are no constraints on what data is allowed, with only the following requirements:

| Parameter    | Requirement |
|--------------|-------------|
| `Name`       | Must be of type `string`. |
| `Values`     | Must be a `[list]` of one or more `strings`. |
| `Expiration` | Must be in [ISO 8601 Date-Time format](https://www.w3.org/TR/NOTE-datetime) and must be specified in UTC.|
| `ClaimType`  | Must be of type `string`. <br> **Note:** The `ClaimType` of "vwac" is reserved for system-generated claims (see below). |

Each developer can define and use whatever values for `Name`, `Value`, and `ClaimType` they require for their specific application, service, or use case.

### Expired claims

The VW.AC Platform automatically removes claims upon reaching their expiration date and time. No additional action is required by the developer to enable this.


## System-Generated Claims

Claims, as set by an application, can be labeled and defined as anything that the business logic of that application or service needs. For example: "Peggy is the renter of this vehicle until midnight Friday".

Claims can also be set by the VW.AC Platform itself. These system-generated claims will have the `ClaimType` set to the reserved value of "vwac".

For example, when you create a user via the "Create user" API operation, the platform automatically creates a system-generated user claim:

![System-generated claims](img/concepts/DXP-Create-User-Response-with-Claim.png)

This system-generated user claim is a combination of:

- The user attribute of `Enabled` (found at the bottom of the "Create user" response body)
- That attribute's value of `True`
- An `Expiration` date (set in the year 9999)
- A `ClaimType` of "vwac"

This system-generated user claim is properly interpreted to mean: "This user is enabled, and will remain enabled until this claim is removed or changed".

**Note:** It is important to distinguish that attributes and properties (such as `FirstName`, `LastName`, or `UserOrgLevel1`) are **not** the same as claims. Attributes and additional properties are used to further describe and define individual users, but **only claims** can be used to establish permissions and grant capabilities. 

This explains why the user attribute `"Enabled": true` is rendered by the system as a claim, so it can be used by the Claims-Based Access Control (CBAC) mechanism.


## Scope of a Claim

A claim is often a statement about a single object, but a claim can also be used to establish an association *between* objects.

- A **user claim** defines facts about a user object.
- A **vehicle claim** defines facts about a vehicle object.
- A **vehicle-user claim** defines facts about the relationship *between* a vehicle object and a user object.

### Other claim types

Additional claim types beyond the common **user claims** and **vehicle claims** are also allowed. These additional claims, called **entity claims**, are used to store declarations about a particular development team's project, application, service or feature. 

Similar to **vehicle-user** claims, you can create an association between "users and entities" as well as between "vehicles and entities"; or even a claim that associates "users, vehicles, and entities" (all three primary object types) together.


## Claim Examples

Basic, or simple, claims might be written as:

- Role is "Renter"
- GeoBoundary is set to "USA and Canada"
- Allowed Remote Commands include: "Lock and unlock doors" and "Remote engine start"

These informal descriptions, when translated into formal JSON-based ClaimSets, might become:

```json
"Claims": [{
    "Name": "Role",
    "Values": ["Renter"],
    "Expiration": "2021-09-26T23:59:59+00:00",
    "ClaimType": "ExoticCarRentals"
}]
```

```json
"Claims": [{
    "Name": "GeoBoundary",
    "Values": ["USA","CAN"],
    "Expiration": "2021-09-26T23:59:59+00:00",
    "ClaimType": "ExoticCarRentals"
}]
```

```json
"Claims": [{
    "Name": "CommandPermissions",
    "Values": [
        "RemoteLockDoors",
        "RemoteUnlockDoors", 
        "RemoteStartEngine"],
    "Expiration": "2021-09-26T23:59:59+00:00",
    "ClaimType": "ExoticCarRentals"
}]
```

## Claim Paths

When you submit or review claims, you will notice a parameter called "claimsPath":

![Claim paths](img/concepts/DXP-Claims-Paths.png)

User claims, vehicle claims, user-vehicle claims, etc. are organized and stored in a hierarchical tree structure to allow for more efficient retrieval. 

Rather than requesting the entire claims tree structure, a device can request only the relevant "leaf nodes" of the claims tree, thereby minimizing the amount of data being transmitted over the cellular network.


## Related Content

- See the tutorial: [Define & Configure > Create a User](./training4.0%2FTry-it-03-Create-a-User.html)
- See the tutorial: [Define & Configure > Define Claims](./training4.0%2FTry-it-04-Define-Claims.html)
