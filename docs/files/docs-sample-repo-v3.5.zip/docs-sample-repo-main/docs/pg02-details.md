## E3 Overview

The vision of Volkswagen's CARIAD group is to build a [unified technology and software platform](https://cariad.technology/de/en/solutions/unified-software.html), including: a vehicle OS, a vehicle cloud platform, and a new unified architecture for all of Volkswagen Group’s brands.

The in-vehicle Volkswagen Operating System (VW.OS) connects to our global Volkswagen Automotive Cloud (VW.AC). 

The interplay between the vehicle and the cloud, the [Big Loop](https://newsroom.porsche.com/en/2021/innovation/porsche-engineering-big-data-loop-25029.html), will keep vehicles up-to-date, with the newest features, applications, and on-demand functions.

The guides and charts below will help new developers acclimate more quickly to the terms, acronyms, and abbreviations related to VW's **End-to-End Electronics** (E<sup>3</sup>) Architecture.


## Vehicle Construction Platforms

| Market Segment            | Conventional/ICE | Electric|
|---------------------------|------------------|---------|
| "Value" Market Vehicles   | MQB              | MEB 
| "Premium" Market Vehicles | MSB / MLB / PPC  | J1 / PPE 

| Platform | Conventional/ICE (Internal Combustion Engine) | 
|----------|-----------------------------------------------|
| **MQB**  | *German: Modularer Querbaukasten (Modular Transverse)* <br/><br/> MQB is the modular construction platform for non-electric, internal combustion engine (ICE) vehicles for Volkswagen Group's (VWG's) "Volume" cars. The MQB platform uses a *transverse* engine. <br/><br/> MQB vehicles include: Audi A1, A3, Q3, TT; SEAT Ibiza & Leon; VW Golf, Passat, Tiguan, etc. <br/><br/> Launched/Announced: 2012 <br/> MQB "Evo updates" introduced: 2019
| **MSB**  | *German: Modularer Standardantriebsbaukasten (Modular Standard)* <br/><br/> MSB is the modular construction platform for non-electric vehicles for Porsche. Includes vehicles with longitudinally mounted engines and gearboxes, and both four-wheel and rear-wheel drive vehicles. <br/><br/> MSB vehicles include: Second generation Porsche Panamera; Bentley Continental GT and Bentley Flying Spur. <br/><br/> Launched/Announced: 2016
| **MLB**  | *German: Modularer Längsbaukasten (Modular Longitudinal)* <br/><br/> MLB is the modular construction platform for non-electric vehicles for VWG's "Premium" cars. The MLB platform uses a *longitudinal* engine. <br/><br/> MLB vehicles include: Audi A4, A5, A6, A7, A8, Q5, Q7, Q8 & Audi e-tron; VW Touareg; Lamborghini Urus; Bentley Bentayga; Porsche Macan, Cayenne, etc. <br/><br/> Launched/Announced: 2007 <br/> MLB "Evo updates" introduced: 2015
| **PPC**  | *Premium Platform Conventional*
| **References:** | [Blog: Difference between MQB and MLB Volkswagen Group modular platforms](https://blog.caristaapp.com/difference-between-mqb-and-mlb-volkswagen-group-modular-platforms-b9dd4ca96b7d) <br/> [Wikipedia: Volkswagen Group MQB platform](https://en.wikipedia.org/wiki/Volkswagen_Group_MQB_platform) <br/> [Wikipedia: Volkswagen Group MSB platform](https://en.wikipedia.org/wiki/Volkswagen_Group_MSB_platform) <br/> [Wikipedia: Volkswagen Group MLB platform](https://en.wikipedia.org/wiki/Volkswagen_Group_MLB_platform)

| Platform | Electric         |
|----------|------------------|
| **MEB**  | *German: Modularer E-Antriebs-Baukasten (Modular Electric Drive Assembly)* <br/><br/> MEB is the modular construction platform for electric vehicles (EVs) for VWG's "Volume" cars. <br/><br/> The MEB vehicle platform was created with the goal of switching the Volkswagen Group's vehicle line-up to EVs, and spans many sizes and segments including all-wheel drive vehicles. <br/><br/> MEB vehicles include: Audi Q4 e-tron & Q4 Sportback e-tron; Cupra Born; Škoda Enyaq; Volkswagen ID.3, ID.4, ID.6, etc. <br/><br/> Launched/Announced: 2017
| **J1**   | Modular design for initial performance electric vehicles. Based on the conventional (ICE) MSB platform. <br/><br/> J1 vehicles include: Porsche Taycan (2019–present) Audi e-tron GT (2020–present). <br/><br/> Launched/Announced: 2019
| **PPE**  | *Premium Platform Electric* <br/><br/> PPE is the modular construction platform for *electric* vehicles (EVs) for VWG's "Premium" cars being developed by Audi and Porsche. <br/><br/> **PPE41** vehicles include: Porsche eMacan; Audi A6 e-tron & Q5 e-tron to ship in 2022. <br/><br/> **PPE51** vehicles include: ```TBD``` to ship in ```TBD```. <br/><br/> Launched/Announced: 2020
| **References:** | [VW: Modular electric drive matrix (MEB)](https://www.volkswagen-newsroom.com/en/modular-electric-drive-matrix-meb-3677) <br/> [Wikipedia: Volkswagen Group MEB platform](https://en.wikipedia.org/wiki/Volkswagen_Group_MEB_platform) <br/> [Wikipedia: Volkswagen Group Premium Platform Electric](https://en.wikipedia.org/wiki/Volkswagen_Group_Premium_Platform_Electric)


## Vehicle & Data Platform Matrix

| Vehicle Platform                           | ST | E3     | ODP     | Data Store | Comments  |
|--------------------------------------------|:--:|:------:|:-------:|:----------:|-----------|
| **Legacy**                                 | -  | -      | -       | MBB (v1.5) | Legacy VWG vehicles. <br/> Infotainment System Apps, Smart phone Apps, & early Connected Car platforms. <br/> MBB = Data center-based (on-premise) storage.
| **MQB/MLB** <br/> (ex. A4/Q5)              | -  | E3 1.0 | ODP 1.0 | AWS        | Legacy VWG vehicles. <br/> Same functionality as MBB but lifted and shifted into the AWS cloud platform.
| **MEB** <br/> (ex. ID.4)                   | X1 | E3 1.1 | ODP 1.5 | AWS        | First generation of VWG electric vehicles.
| **PPC** <br/> **PPE41** <br/> (ex. eMacan) | X2 | E3 1.2 | ODP 2.0 | VW.AC      | Current VW.AC focus. <br/> A "Hybrid Architecture" approach (Valtech, WirelessCar). <br> Monitoring new (legacy) vehicle registrations in ODP 1.0 and then mirroring that same vehicle registration data into the VW.AC Platform.
| **PPE51** <br/> (ex. ```TBD```)            | X3 | E3 2.0 | ODP 2.0 | VW.AC      | Long-term VW.AC focus. <br/> aka "Project Trinity"


## Terms & Definitions

| Term      | Description |
|-----------|-------------|
| **ST**    | *Solution Train* <br/><br/> Cross-department CARIAD development teams working on the different E3/ODP solutions: <br/> - **X1** Solution Train = E3 1.1 <br/> - **X2** Solution Train = E3 1.2 <br/> - **X3** Solution Train = E3 2.0
| **E3**    | *End-to-End Electronics architecture (E<sup>3</sup>, E-cubed)* <br/><br/> - **E3 1.0** = Legacy vehicles (Smart phone Apps & Connected Car platforms). <br/> - **E3 1.1** = First generation electric vehicles (ID.4, etc.). <br/> - **E3 1.2** = Current VW.AC focus. A "Hybrid Architecture" (HA) approach to mirror legacy vehicle data into the VW.AC Platform. <br/> - **E3 2.0** = Long-term VW.AC focus.
| **ODP**   | *One Digital Platform* <br/><br/> A concept for using a single backend data platform to house all of a customer's account information and user preferences. Enabling a user to login once and control all of their vehicles and settings. This "one platform" has been migrating from an on-premise/datacenter-based system (MBB) to Amazon Web Services (AWS) and now to the VW.AC Cloud Platform (leveraging Microsoft's Azure Cloud).
| **MBB**   | *German: Modularer Backend Baukasten* <br/><br/> A data and communications platform launched by VW in 2011 to enable vehicle connectivity and digital services. MBB acts as the primary data store and master database for users to authenticate to; enabling apps, customer portals and frontend services like "MyAudi" and "MyVW" mobile phone apps. <br/><br/> Reference: [MyAudi Apps](https://www.audiusa.com/us/web/en/myaudi/apps.html)
| **AWS**   | Amazon Web Services. A multi-purpose cloud platform operated by Amazon.
| **VW.AC** | Volkswagen Automotive Cloud. A purpose-built, automotive-oriented cloud platform operated by VW.

| Mobility Service Offerings |       |
|--------------|---------------------|
| **MOD**      | *German: Mobile Online Dienste (Services) (Mobility on Demand)* <br/><br/> Tech stack(s) to provide "Connected Vehicle" services to users and owners of both legacy and newer cars. Services might include: Fleet Management Tools, Consumer Subscriptions, Location-based offerings, etc.
| **MOD 1, 2** | Apps embedded in the Infotainment screen (Ex. Spotify and Android Auto) connecting to MBB.
| **MOD 3**    | Infotainment Apps connecting to ODP 1.0/AWS.
| **MOD 4**    | Smart Phone Apps (Ex. "MyAudi") connected to ODP 1.5/AWS.
| **MOD 5**    | The future of IoT Automotive Edge connectivity to ODP 2.0/VW.AC.
