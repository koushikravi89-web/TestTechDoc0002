## Repo for [[TEAM NAME]] Documentation Content

This is a complete template of a Docs repo with sample files, including: Markdown, TechDocs, MkDocs files, and pipeline/workflows for GitHub.com and ADO. 

You should be able to BUILD, PREVIEW and PUBLISH Docs to the DXP using this template repo as a start!

*NOTE: Please update this README.md to contain the following information for your Repo:*


### Description

One or two paragraphs **DESCRIBING** what is in your Repo, how it is used, and who will be the users of the content.


### Ownership

Who **OWNS** this content: Names, Contacts, Emails, Team(s), etc.


### Audience

Who **USES** the content: Which Teams, Groups, Brands, etc. are the intended audience of the content.


### Access Restrictions

Who is allowed to **VIEW/ACCESS** the content: 
- EU?
- NAR?
- China?


### Tags and Metadata

To aid in searching and finding your content, please include any relevant **TAGS** such as: 
- Platform (VW.AC, ODP 1.0/1.2/1.5, Hybrid Architecture)
- Environment (Cloud-based, Vehicle-based, Data-oriented)
- Brand (VW, Audi, Porsche, etc.); REgion (China, EU, NA, etc.)
